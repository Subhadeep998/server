const express = require("express");
const app = express();
const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("🎉 Hello from your server!");
});

app.listen(port, () => {
  console.log(`Your magic server is ready on port ${port}`);
});
